/* 
 * Anthony Muller
 * February 3, 2014
 * Make a text base RPG fighting game.
 */

//system libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <ctime>
using namespace std;

//global constants

//function prototypes

//execution begins here
int main(int argc, char** argv) {
//declare variables
unsigned int SPkill,pdef,mdef;
int str,mstr;
float hp,mhp;
char dec,dec1,dec1a,choice;
bool decB = true;
//hp
hp=100;
str=3;
pdef=15;
do{
    //main menu for dorin adventure
    cout<<"Welcome to the adventure of Dorin, the drunken dwarf!!"<<endl;
    cout<<endl;
    cout<<"You make decisions and help Dorin on his wild adventures."<<endl;
    cout<<endl;
    cout<<"Want to read the instructions? ENTER 1"<<endl;
    cout<<"To play?                       ENTER 2"<<endl;
    cout<<"To Exit                        ENTER 3"<<endl;
    cin>>choice;
    switch(choice){
                case '2':{
    cout<<"       Dorin The Drunken Dwarf                 "<<endl;
    cout<<"   Strength       = "<<str<<endl;
    cout<<"   Health Points  = "<<hp<<endl;
    cout<<"   Armor          = "<<pdef<<endl;
    cout<<endl;
    cout<<"Are you ready to begin? y/n"<<endl;
    cin>>dec;
    
    if(dec=='y'||dec=='Y'){
        cout<<endl;
        cout<<endl;
        cout<<"Dorin the drunken dwarf, is pretty damn drunk! So he needs your help!!"<<endl;
        cout<<"The drunk dwarf stands at a fork in the road, should he go left into the enchanted forest?"<<endl;
        cout<<"Or should he go right into the cave of despair?"<<endl;
        cout<<endl;
        cout<<"To send Dorin into the enchanted forest enter L"<<endl;
        cout<<"To send Dorin into the cave of despair enter R"<<endl;
        cin>>dec1;
        //decisions
        if(dec1=='l' || dec=='L'){//to the enchanted forest
            mstr=5;
            mdef=10;
            mhp=20;
            //cosmetic
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<"--------------------------------------------------------------------------------------------------------"<<endl;
            //start
            cout<<"The dwarf stumbles down the road into the forest. The air is thick and musty."<<endl;
            cout<<"The smell of decaying leaves fills the air, the drunken dwarf doesn't seem to notice"<<endl;
            cout<<"The further into the forest you get the air gets more and more still."<<endl;
            cout<<endl;
            cout<<"Out of nowhere a giant spider burst from the trees! It runs directly towards the dwarf!"<<endl;
            cout<<"Dorin pulls out his giant axe and prepares to fight!!"<<endl;
            cout<<endl;
            //combat with (while,do,if,if else, if else if, ect)
            //also for loop
            for( SPkill=0;SPkill<3; ){
                do{
                        //Dorin attack
                        cout<<"--------------------------------------------------"<<endl;
                        cout<<"Dorin takes a swing at the spider!!"<<endl;
                        cout<<endl;//cosmetic
                        cout<<"Press R to roll, or anything else to run away"<<endl;
                        cin>>dec1a;
                        //roll d20
                        if(dec1a=='r' || dec1a=='R'){
                                int rolla;
                                rolla = rand()%20+1;
                                //HUD 
                                cout<<"    Dorin"<<endl;
                                cout<<"   Str = "<<str<<endl;
                                cout<<"   HP  = "<<fixed<<setprecision(2)<<hp<<endl;
                                cout<<"   Ar  = "<<pdef<<endl;
                                cout<<" Kills = "<<SPkill<<endl;
                                cout<<endl;
                                cout<<"Dorin rolled a "<<rolla<<" + "<<str<<"(strength mod)"<<endl;
                                //roll for damage
                                if(rolla+str>=mdef){
                                        cout<<"Dorin HIT!!"<<endl;
                                        int rolla2;
                                        rolla2 = rand()%10+1;
                                        mhp=mhp-rolla2;
                                        if(mhp<=0){
                                            //reset and count kills
                                            cout<<"Dorin killed the Spider!!!"<<endl;
                                            cout<<endl;
                                            cout<<"Another spider jumps out to challenge Dorin!"<<endl;
                                            SPkill++;
                                            if(SPkill>=3){
                                                decB=false;
                                            }else if(decB=true && SPkill<=2){
                                                mhp=20;
                                            }
                                            
                                         }else{
                                                cout<<"Dorin did "<<rolla2<<" damage, The spider has "<<mhp<<" health points left.     ("<<SPkill<<" kills)"<<endl;
                                                cout<<endl;
                                        }
                
                                //miss        
                                }else{
                                        cout<<endl;
                                        cout<<"Dorin missed!"<<endl;
                                        cout<<endl;
                                }
                                //if wrong input        
                                }else{
                                cout<<"Enter a valid option"<<endl;
                                cout<<"You skipped your turn"<<endl;
                                }
                        
                //spider attack
                        cout<<"--------------------------------------------------"<<endl;
                        cout<<"The giant spider tries to bite Dorin!"<<endl;
                        cout<<endl;
                        //roll d20
                        int roll;
                        roll = rand()%20+1;
                        //results
                        cout<<"The spider rolled a "<<roll<<" + "<<mstr<<"(Monster Strength Mod)"<<endl;
                        cout<<endl;
                        //roll d10 for damage
                        if(roll+mstr>=pdef){
                        cout<<"The spider HIT!!"<<endl;
                        cout<<endl;
                        int roll2;
                                roll2 = rand()%10+1;
                                hp=hp-(roll2+mstr);
                                cout<<"The spider did "<<roll2<<" + "<<mstr<<"(strength mod)"<<" damage, Dorin has "<<hp<<" health points left     ("<<SPkill<<" kills)"<<endl;
                                if(hp<=0){
                                    decB=false;
                                }
                        //miss
                        }else{
                        cout<<"The spider missed!"<<endl;
                        cout<<endl;
                        }
                }while(decB==true);
                
            }
            
            
            cout<<endl;
            cout<<endl;
            if(hp<=0){
                cout<<"--------------------------------------------------------"<<endl;//cosmetic
                cout<<"Unfortunatly, Dorin and yourself were slain by the "<<endl;
                cout<<"fearsome Spider. Your corpses will be eaten.."<<endl;
            }else{
                cout<<"--------------------------------------------------------"<<endl;//cosmetic
                cout<<"You helped Dorin through the Enchanted Forest!!!"<<endl;
                cout<<"Dorin will never forget you!!"<<endl;    
                }
        }else if(dec1=='r' || dec1=='R'){//to the cave of despair
            mstr=1;
            mhp=120;
            cout<<endl;
            cout<<"-------------------------------------------------------------------------------------------"<<endl;//cosmetic
            cout<<"Dorin stumbles off of the road and goes to the entrance"<<endl;
            cout<<"of the Cave of Despair, on the floor before the entrance"<<endl;
            cout<<"there are tracks leading into the cave. You do not "<<endl;
            cout<<"recognize what left the tracks. As you and Dorin "<<endl;
            cout<<"venture deeper into the cave, it gets darker and "<<endl;
            cout<<"darker. Luckily Dorin has a torch with him, that he"<<endl;
            cout<<" uses to light the path. After a while the thick smell"<<endl;
            cout<<"of rotting meat fills the cave. From behind you hear dragging noises"<<endl;
            cout<<"You turn around in time to see a Zombie dragging itself towards Dorin and yourself!!"<<endl;
            
            //combat
            do{
                //zombie attack
                cout<<"------------------------------------------------------------------"<<endl;//cosmetic
                cout<<"The Zombie tries to eat Dorin!"<<endl;
                cout<<endl;
                //roll d20
                int roll;
                roll = rand()%20+1;
                //results
                cout<<"The Zombie rolled a "<<roll<<endl;
                cout<<endl;
                //roll d10 for damage
                if((roll+mstr)>=pdef){
                    cout<<"The Zombie HIT!!"<<endl;
                    cout<<endl;
                    int roll2;
                        roll2 = rand()%4+1;
                        hp=hp-(roll2+mstr);
                        cout<<"The Zombie did "<<roll2<<" damage, Dorin has "<<hp<<" health points left"<<endl;
                //
                }else{
                    cout<<"The Zombie missed!"<<endl;
                    cout<<endl;
                }
                //Dorin attack
                cout<<"----------------------------------------------------------------"<<endl;//cosmetic
                cout<<"Dorin takes a swing at the Zombie!!"<<endl;
                cout<<endl;//cosmetic
                cout<<"Press R to roll, or anything else to run away"<<endl;
                cin>>dec1a;
                //roll d20
                if(dec1a=='r' || dec1a=='R'){
                        int rolla;
                        rolla = rand()%20+1;
                        //HUD 
                        cout<<"    Dorin"<<endl;
                        cout<<"   Str = "<<str<<endl;
                        cout<<"   HP  = "<<fixed<<setprecision(2)<<hp<<endl;
                        cout<<"   Ar  = "<<pdef<<endl;
                        cout<<" Kills = "<<SPkill<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"-------------------------"<<endl;//cosmetic
                        cout<<"Dorin rolled a "<<rolla<<endl;
                        //roll for damage
                        if(rolla>=mdef){
                                cout<<"Dorin HIT!!"<<endl;
                                int rolla2;
                                rolla2 = rand()%10+1;
                                mhp=mhp-rolla2;
                                cout<<"Dorin did "<<rolla2<<" damage, The Zombie has "<<mhp<<" health points left"<<endl;
                                cout<<endl;
                
                        //miss        
                        }else{
                                cout<<endl;
                                cout<<"Dorin missed!"<<endl;
                                cout<<endl;
                }
                //if wrong input        
                }else{
                    hp-100;
                    cout<<"-----------------------------------------------------"<<endl;//cosmetic
                    cout<<"Why did you leave Dorin to fight and die alone?"<<endl;
                }
            }
            while(hp>0 && mhp>0);
            cout<<endl;
            if(hp<=0){
                cout<<"----------------------------------------------------------"<<endl;//cosmetic
                cout<<"Unfortunatly, Dorin and yourself were slain by the "<<endl;
                cout<<"fearsome Zombie. Your corpses will soon reanimate and "<<endl;
                cout<<"join the legions of the dead..."<<endl;
            }else{
                cout<<"You helped Dorin through the Cave of Despair!!!"<<endl;
                cout<<"Dorin will never forget you!!"<<endl;
            }
            
        }else{
            cout<<"-----------------------------------------------------------------------------------------------------"<<endl;//cosmetic
            cout<<"You left that stupid drunk dwarf, for better or worse. He will probably get you killed anyway."<<endl;
        }
        
    }else{
        cout<<"--------------------------------------------------------"<<endl;//cosmetic
        cout<<"Come back when you are ready to help Dorin!!"<<endl;
    }
    break;
                }
                case '1':{
                    cout<<endl;
    cout        <<"If you are unfamiliar with paper and pencil RPGs"
                <<"The way combat will be decided is through the d20 mechanic.\n";
    cout        <<"Which is the roll of a 20 sided die, and if the roll + your modifiers "
                <<"is high enough, depending on the monster, you will hit it. If you hit it \n";
    cout        <<"then you roll damage. Damage is subtracted from your HP (Health Points) If the player or "
                <<"an enemy have their HP droped to 0 or lower, they die.\n";
    cout<<endl;
    break;
                }
                case '3':{
    return 0;
                }
}
}while(choice!=3);
}