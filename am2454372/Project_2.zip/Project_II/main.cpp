/* 
 * Anthony Muller
 * February 10, 2014
 * Make a text base RPG fighting game.
 */

//system libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <ctime>
#include <fstream>

using namespace std;

//global constants

//function prototypes
int d20(int);
int d10(int);
int d8(int);
int d4(int);
int d6(int);




//execution begins here
int main(int argc, char** argv) {
//arrays

//declare variables
unsigned int SPkill,pdef,mdef;
int str,mstr,killn;
float hp,mhp;
char charCre1,charCre2,charCre2a,dec,dec1,dec1a,choice;
bool decB = true;
string pname,fline;
//hp
hp=100;
//set time for random numbers
srand(time(0));
do{
    
    //main menu for adventure
    //read from file
    ifstream firstline;
    firstline.open("chars.txt");
    firstline>>fline;
    cout<<fline;
    firstline.close();
    //end read from file
    cout<<endl;
    cout<<"To the the Adventure of the Twilight Forest!!"<<endl;
    cout<<"You make decisions and go on an adventure."<<endl;
    cout<<endl;
    cout<<"Want to read the instructions? ENTER 1"<<endl;
    cout<<"To Character Creation          ENTER 2"<<endl;
    cout<<"To Exit                        ENTER 3"<<endl;
    cin>>choice;
    switch(choice){
                case '2':{
                    //character creation
    cout<<endl;
    cout<<endl;
    cout<<endl;
    cout<<"--------------------------------------------------------------"<<endl;
    cout<<"Welcome to the character creation menu"<<endl;
    cout<<"Here we will make your character for the adventure!!"<<endl;
    cout<<endl;
    //get STR
    cout<<"Roll to determine Strength"<<endl;
    cout<<"Strength is 1d6 + 2"<<endl;
    cout<<endl;
    cout<<"Enter R to Roll"<<endl;
    cin>>charCre1;
    cout<<endl;
    if(charCre1=='r' || charCre1=='R'){
                         int rollstrm1;
                         rollstrm1 = d8 (0);
                         cout<<"You rolled a "<<rollstrm1<<endl;
                         str=rollstrm1+2;
                         cout<<"Your strength modifier is "<<str<<endl;
                         cout<<endl;
                         cout<<endl;
    }else{
        cout<<"Enter a Correct option"<<endl;
    }
    cout<<"Roll to determine Armor"<<endl;
    cout<<"Armor is 2d6 + 10"<<endl;
    cout<<endl;
    cout<<"Enter R to roll"<<endl;
    cin>>charCre2;
    if(charCre2=='r' || charCre2=='R'){
                         int rollarm;
                         rollarm = d6 (0);
                         cout<<"You rolled a "<<rollarm<<endl;
                         cout<<endl;
                         cout<<"Enter R to roll"<<endl;
                         cin>>charCre2a;
                         if(charCre2a=='r' || charCre2a=='R'){
                                int rollarm1;
                                rollarm1 = d6(0);
                                cout<<"You rolled a "<<rollarm1<<endl;
                                pdef=rollarm+rollarm1+10;
                                cout<<"Your armor value is "<<pdef<<endl;
                                cout<<endl;
                                cout<<endl;
                        }else{
                        cout<<"Enter a Correct option"<<endl;
    }
                         
    }else{
        cout<<"Enter a Correct option"<<endl;
    }
    cout<<endl;
    cout<<"Enter a name for your character"<<endl;
    cout<<"      No spaces please!"<<endl;
    cout<<endl;
    cin>>pname;
    cout<<endl;
    cout<<endl;
    //save char sheet stats
    ofstream writesheet;
    writesheet.open("charSheet.txt");
    writesheet<<pname<<" STR-"<<str<<" ARMOR-"<<pdef<<endl;
    writesheet.close();
    //end char creation
    cout<<"---------------------------------------"<<endl;
    cout<<"   "<<pname<<endl;;
    cout<<endl;
    cout<<"Strength       = "<<str<<endl;
    cout<<"Health Points  = "<<hp<<endl;
    cout<<"Armor          = "<<pdef<<endl;
    cout<<endl;
    cout<<"Are you ready to begin? y/n"<<endl;
    cin>>dec;
    
    if(dec=='y'||dec=='Y'){
        cout<<endl;
        cout<<endl;
        cout<<pname<<" stands at a fork in the road, should he go left into the enchanted forest?"<<endl;
        cout<<"Or should he go right into the cave of despair?"<<endl;
        cout<<endl;
        cout<<"To send "<<pname<<" into the enchanted forest enter L    (EASY)"<<endl;
        cout<<"To send "<<pname<<" into the cave of despair enter R     (HARD)"<<endl;
        cin>>dec1;
        //decisions
        if(dec1=='l' || dec=='L'){//to the enchanted forest
            mstr=5;
            mdef=10;
            mhp=20;
            //cosmetic
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<endl;
            cout<<"--------------------------------------------------------------------------------------------------------"<<endl;
            //start
            cout<<""<<pname<<" walks down the road into the forest. The air is thick and musty."<<endl;
            cout<<"The smell of decaying leaves fills the air, "<<pname<<" doesn't seem to care."<<endl;
            cout<<"The further into the forest "<<pname<<" gets the air gets more and more still."<<endl;
            cout<<endl;
            cout<<"Out of nowhere a giant spider burst from the trees! It runs directly towards "<<pname<<"!!"<<endl;
            cout<<pname<<" pulls out his giant axe and prepares to fight!!"<<endl;
            cout<<endl;
            //combat with (while,do,if,if else, if else if, ect)
            //also for loop
            //kills needed
            killn=d6 (1);
            for( SPkill=0;SPkill<killn; ){
                do{
                        //Dorin attack
                        cout<<"--------------------------------------------------"<<endl;
                        cout<<pname<<" takes a swing at the spider!!"<<endl;
                        cout<<endl;//cosmetic
                        cout<<"Press R to roll, or anything else to skip your turn"<<endl;
                        cin>>dec1a;
                        //roll d20
                        if(dec1a=='r' || dec1a=='R'){
                                int rolla;
                                rolla = d20 (str);
                                //HUD 
                                cout<<"   "<<pname<<endl;
                                cout<<"   Str = "<<str<<endl;
                                cout<<"   HP  = "<<fixed<<setprecision(2)<<hp<<endl;
                                cout<<"   Ar  = "<<pdef<<endl;
                                cout<<" Kills = "<<SPkill<<endl;
                                cout<<"-----------------------------"<<endl;
                                cout<<endl;
                                cout<<pname<<" rolled a total of "<<rolla<<endl;
                                //roll for damage
                                if(rolla>=mdef){
                                        cout<<pname<<" HIT!!"<<endl;
                                        cout<<"--------------"<<endl;
                                        cout<<endl;
                                        int rolla2;
                                        rolla2 = d20 (str);
                                        mhp=mhp-rolla2;
                                        cout<<"The spider has "<<mhp<<" HP left"<<endl;
                                        if(mhp<=0){
                                            //reset and count kills
                                            cout<<pname<<" killed the Spider!!!"<<endl;
                                            cout<<endl;
                                            cout<<"Another spider jumps out to challenge "<<pname<<endl;
                                            SPkill++;
                                            if(SPkill>=3){
                                                decB=false;
                                            }else if(decB=true && SPkill<killn){
                                                mhp=20;
                                            }
                                            
                                         }else{
                                                cout<<pname<<" did a total of "<<rolla2<<" damage, The spider has "<<mhp<<" health points left."<<endl;
                                                cout<<endl;
                                        }
                
                                //miss        
                                }else{
                                        cout<<endl;
                                        cout<<pname<<" missed!"<<endl;
                                        cout<<endl;
                                }
                                //if wrong input        
                                }else{
                                cout<<"Enter a valid option"<<endl;
                                cout<<"You skipped your turn"<<endl;
                                }
                        
                //spider attack
                        cout<<"--------------------------------------------------"<<endl;
                        cout<<"The giant spider tries to bite "<<pname<<endl;
                        cout<<endl;
                        //roll d20
                        int roll;
                        roll = d20 (mstr);
                        //results
                        cout<<"The spider rolled a  total of "<<roll<<endl;
                        cout<<endl;
                        //roll d10 for damage
                        if(roll>=pdef){
                        cout<<"The spider HIT!!"<<endl;
                        cout<<endl;
                        int roll2;
                                roll2 = d10 (mstr);
                                hp=hp-(roll2);
                                cout<<"The spider did a total of "<<roll2<<" damage, "<<pname<<" has "<<hp<<" health points left     ("<<SPkill<<" kills)"<<endl;
                                if(hp<=0){
                                    decB=false;
                                }
                        //miss
                        }else{
                        cout<<"The spider missed!"<<endl;
                        cout<<endl;
                        }
                }while(decB==true);
                
            }
            
            
            cout<<endl;
            cout<<endl;
            if(hp<=0){
                cout<<"--------------------------------------------------------"<<endl;//cosmetic
                cout<<"Unfortunatly, "<<pname<<" was slain by the "<<endl;
                cout<<"fearsome Spider. Your corpse will be eaten.."<<endl;
            }else{
                cout<<"--------------------------------------------------------"<<endl;//cosmetic
                cout<<"You helped "<<pname<<" through the Enchanted Forest!!!"<<endl; 
                cout<<endl;
                cout<<"You have beaten easy mode!! Good Job!!!"<<endl;
                cout<<"-------------------------------------------------------"<<endl;
                cout<<endl;
                }
        }else if(dec1=='r' || dec1=='R'){//to the cave of despair
            mstr=1;
            mhp=120;
            mdef=12;
            cout<<endl;
            cout<<"-------------------------------------------------------------------------------------------"<<endl;//cosmetic
            cout<<pname<<" stumbles off of the road and goes to the entrance"<<endl;
            cout<<"of the Cave of Despair, on the floor before the entrance"<<endl;
            cout<<"there are tracks leading into the cave."<<pname<<" does not "<<endl;
            cout<<"recognize what left the tracks. As "<<pname<<endl;
            cout<<"ventures deeper into the cave, it gets darker and "<<endl;
            cout<<"darker. Luckily "<<pname<<" has a torch , that is"<<endl;
            cout<<"used to light the path. After a while the thick smell"<<endl;
            cout<<"of rotting meat fills the cave. From behind "<<pname<<" hears dragging noises"<<endl;
            cout<<pname<<" turns around in time to see a Zombie dragging itself into biting range "<<endl;
            
            //combat
            do{
                //zombie attack
                cout<<"------------------------------------------------------------------"<<endl;//cosmetic
                cout<<"The Zombie tries to eat "<<pname<<"!"<<endl;
                cout<<endl;
                //roll d20
                int roll;
                roll = d20 (mstr);
                //results
                cout<<"The Zombie rolled a total of "<<roll<<endl;
                cout<<endl;
                //roll d10 for damage
                if((roll+mstr)>=pdef){
                    cout<<"The Zombie HIT!!"<<endl;
                    cout<<endl;
                    int roll2;
                        roll2 = d4 (mstr);
                        hp=hp-(roll2);
                        cout<<"The Zombie did a total of "<<roll2<<" damage, "<<pname<<" has "<<hp<<" health points left"<<endl;
                //
                }else{
                    cout<<"The Zombie missed!"<<endl;
                    cout<<endl;
                }
                //Dorin attack
                cout<<"----------------------------------------------------------------"<<endl;//cosmetic
                cout<<pname<<" takes a swing at the Zombie!!"<<endl;
                cout<<endl;//cosmetic
                cout<<"Press R to roll, or anything else to skip your turn"<<endl;
                cin>>dec1a;
                //roll d20
                if(dec1a=='r' || dec1a=='R'){
                        int rolla;
                        SPkill=0;
                        rolla = d20 (str);
                        //HUD 
                        cout<<"    "<<pname<<endl;
                        cout<<"   Str = "<<str<<endl;
                        cout<<"   HP  = "<<fixed<<setprecision(2)<<hp<<endl;
                        cout<<"   Ar  = "<<pdef<<endl;
                        cout<<" Kills = "<<SPkill<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"-------------------------"<<endl;//cosmetic
                        cout<<pname<<" rolled a total of "<<rolla<<endl;
                        //roll for damage
                        if(rolla>=mdef){
                                cout<<pname<<" HIT!!"<<endl;
                                int rolla2;
                                rolla2 = d10(str);
                                mhp=mhp-rolla2;
                                cout<<pname<<" did a total of "<<rolla2<<" damage, The Zombie has "<<mhp<<" health points left"<<endl;
                                cout<<endl;
                
                        //miss        
                        }else{
                                cout<<endl;
                                cout<<pname<<" missed!"<<endl;
                                cout<<endl;
                }
                //if wrong input        
                }else{
                    cout<<"-----------------------------------------------------"<<endl;//cosmetic
                    cout<<pname<<"You have skipped your turn"<<endl;
                }
            }
            while(hp>0 && mhp>0);
            cout<<endl;
            if(hp<=0){
                cout<<"----------------------------------------------------------"<<endl;//cosmetic
                cout<<"Unfortunatly, "<<pname<<" was slain by the "<<endl;
                cout<<"fearsome Zombie. Your corpse will soon reanimate and "<<endl;
                cout<<"join the legions of the dead..."<<endl;
    }else{
            SPkill++;
            cout<<endl;
            cout<<"-------------------------------------------------------------------------------------------"<<endl;//cosmetic
            cout<<pname<<" has defeated the zombie!!"<<endl;
            cout<<endl;
            cout        <<"As the corpse of the zombie falls to the ground"<<endl;
            cout        <<pname<<" hears a laugh from behind ."<<endl;
            cout        <<pname<<" turns around to see an Arch Lich floating behind you."<<endl;
            cout        <<"His blue glowing eyes peirce your very soul."<<endl;
            cout        <<"He says to "<<pname<<"'This cave of Despair will become your tomb'"<<endl;
            cout<<endl;
            cout        <<"The Arch Lich raises his staff and charges!! "<<pname<<endl;
            pdef=pdef-2;
            str=str+2;
            mdef=15;
            mstr=6;
            mhp=150;
            
            
            //combat
            do{
                //zombie attack
                cout<<"------------------------------------------------------------------"<<endl;//cosmetic
                cout<<"The Lich tries to strike "<<pname<<" down with his staff!!"<<endl;
                cout<<endl;
                //roll d20
                int roll;
                roll = d20 (mstr);
                //results
                cout<<"The Lich rolled a "<<roll<<endl;
                cout<<endl;
                //roll d10 for damage
                if((roll)>=pdef){
                    cout<<"The Lich HIT!!"<<endl;
                    cout<<endl;
                    int roll2;
                        roll2 = d4 (mstr);
                        hp=hp-(roll2);
                        cout<<"The Lich did "<<roll2<<" damage, "<<pname<<" has "<<hp<<" health points left"<<endl;
                //
                }else{
                    cout<<"The Lich missed!"<<endl;
                    cout<<endl;
                }
                //Dorin attack
                cout<<"----------------------------------------------------------------"<<endl;//cosmetic
                cout<<pname<<" takes a swing at the Lich!!"<<endl;
                cout<<endl;//cosmetic
                cout<<"Press R to roll, or anything else to skip your turn"<<endl;
                cin>>dec1a;
                //roll d20
                if(dec1a=='r' || dec1a=='R'){
                        int rolla;
                        rolla = d20 (str);
                        //HUD 
                        cout<<"    "<<pname<<endl;
                        cout<<"   Str = "<<str<<endl;
                        cout<<"   HP  = "<<fixed<<setprecision(2)<<hp<<endl;
                        cout<<"   Ar  = "<<pdef<<endl;
                        cout<<" Kills = "<<SPkill<<endl;
                        cout<<endl;
                        cout<<endl;
                        cout<<"-------------------------"<<endl;//cosmetic
                        cout<<pname<<" rolled a total of "<<rolla<<endl;
                        //roll for damage
                        if(rolla>=mdef){
                                cout<<pname<<" HIT!!"<<endl;
                                int rolla2;
                                rolla2 = d10 (str);
                                mhp=mhp-rolla2;
                                cout<<pname<<" did "<<rolla2<<" damage, The Lich has "<<mhp<<" health points left"<<endl;
                                cout<<endl;
                
                        //miss        
                        }else{
                                cout<<endl;
                                cout<<pname<<" missed!"<<endl;
                                cout<<endl;
                }
                //if wrong input        
                }else{
                    hp-100;
                    cout<<"-----------------------------------------------------"<<endl;//cosmetic
                    cout<<pname<<"You have skipped your turn"<<endl;
                }
            }
            while(hp>0 && mhp>0);
            cout<<endl;
            if(hp<=0){
                cout<<"----------------------------------------------------------"<<endl;//cosmetic
                cout<<"Unfortunately, "<<pname<<" was slain by the "<<endl;
                cout<<"fearsome Lich. Your corpse will soon reanimate and "<<endl;
                cout<<"join the legions of the dead..."<<endl;
                cout<<"--------------------------------------------------------------"<<endl;
                cout<<endl;
            }else{
                cout<<"You helped "<<pname<<" through the Cave of Despair!!!"<<endl;
                cout<<endl;
                cout<<"You have beaten hard mode!! Good Job!!!"<<endl;
            }
            }
            
        }else{
            cout<<"-----------------------------------------------------------------------------------------------------"<<endl;//cosmetic
            cout<<"Enter a valid option"<<endl;
        }
        
    }else{
        cout<<"--------------------------------------------------------"<<endl;//cosmetic
        cout<<"Come back when you are ready to explore the Twilight Forest"<<pname<<endl;
        cout<<"--------------------------------------------------------"<<endl;//cosmetic
    }
    break;
                }
                case '1':{
                    cout<<endl;
    cout        <<"If you are unfamiliar with paper and pencil RPGs"
                <<"The way combat will be decided is through the d20 mechanic.\n";
    cout        <<"Which is the roll of a 20 sided die, and if the roll + your modifiers "
                <<"is high enough, depending on the monster, you will hit it. If you hit it \n";
    cout        <<"then you roll damage. Damage is subtracted from your HP (Health Points) If the player or "
                <<"an enemy have their HP droped to 0 or lower, they die.\n";
    cout<<endl;
    cout        <<" '4d6' means you roll 4 6-sided dice, '2d20' means roll 2 20-sided dice, ect"<<endl;
    cout<<endl;
    cout        <<"Character Creation is done like this"<<endl;
    cout<<endl;
    cout        <<"Your Health points always start at 100"<<endl;
    cout<<endl;
    cout        <<"Your strength modifier is determined by a roll of 1d6 + 2"<<endl;
    cout<<endl;
    cout        <<"Your armor value is determined by a roll of 2d6 + 10"<<endl;
    cout<<endl;
    cout        <<"-----------------------------------------------------------------------------------------------"<<endl;
    break;
                }
                case '3':{
    return 0;
                }
}
}while(choice!=3);
}



int d20(int m){
    int r,t;
    r=rand()%20+1;
    t=m+r;
}
int d12(int m){
    int r,t;
    r=rand()%12+1;
    t=m+r;
}
int d10(int m){
    int r,t;
    r=rand()%10+1;
    t=m+r;
}
int d8(int m){
    int r,t;
    r=rand()%8+1;
    t=m+r;
}
int d6(int m){
    int r,t;
    r=rand()%6+1;
    t=m+r;
}
int d4(int m){
    int r,t;
    r=rand()%4+1;
    t=m+r;
}
int arm(int& r){
    int a;
    a=r+10;
}