/* 
 * File:   main.cpp
 * Author: Edwin Gibbs
 * Created on January 13, 2014, 11:33 AM
 * Cheaper to buy or rent
 */

//System Libraries
#include <iostream>
#include <cmath>
using namespace std;

//Global Constants

//Functional Prototypes

//Execution Begins here
int main(int argc, char** argv) {
//Declare Variables
    float payment,loan, rate, n;
            //Input info
            cout<<"Input loan amount in dollars, interest rate per year and ";
            cout<<"compounding period in years"<<endl;
    cin>>loan>>rate>>n;
    //Calculate payments
    float temp = pow (1+rate,n);
    payment = rate * temp * loan /(temp-1);
    cout<<"Payment per month = $"<<payment/12<<endl;
  
    return 0;
}

