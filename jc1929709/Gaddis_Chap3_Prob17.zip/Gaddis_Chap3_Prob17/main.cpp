/* 
 * File:   main.cpp
 * Author: Jennifer Clark
 * Created on January 13, 2014, 11:35 AM
 * Payment on a House v. Renting
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Describe variables
    float intRate, loan, payment, periods;
    //Input Information
    cout<<"Enter Interest Rate"<<endl;
    cin>>intRate;
    cout<<"Enter Number of Compounding Periods in Years"<<endl;
    cin>>periods;
    cout<<"Enter Loan Amount in Dollars"<<endl;
    cin>>loan;
    cout<<payment<<endl;
    //Calculate the Payment
    float temp=pow(1+intRate,periods);
    payment=intRate*temp*loan/(temp-1);
    //Output the payment per month
    cout<<"Payment per month = $"<<payment/12<<endl;
    //Exit Stage Right
    return 0;
}

